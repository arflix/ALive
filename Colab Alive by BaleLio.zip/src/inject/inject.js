chrome.extension.sendMessage({}, function (response) {
	var readyStateCheckInterval = setInterval(function () {
		if (document.readyState === "complete") {
			clearInterval(readyStateCheckInterval);

			// ----------------------------------------------------------
			// This part of the script triggers when page is done loading
			console.log("Hello. This message was sent from scripts/inject.js");
			// ----------------------------------------------------------
			setInterval(clickConnect, 10000);
			setInterval(ligboxConnect, 60000);
		}
	}, 10);
});

// Credit to BaleLio
function ClickConnect(){
    console.log("LOL"); 
    document.querySelector("#cell-8QyPK88zuQLI colab-run-button").click() // Change id here
}
setInterval(ClickConnect,10000)

function ligboxConnect() {
	try {
		document.querySelector("paper-dialog paper-button#ok").click()	
		console.log('Prevented disconnection')
	} catch (error) {
		console.log(error);
	}
}